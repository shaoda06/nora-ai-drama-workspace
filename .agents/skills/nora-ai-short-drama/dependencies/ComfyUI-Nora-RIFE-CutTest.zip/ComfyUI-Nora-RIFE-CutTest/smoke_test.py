"""Standalone real-Torch/real-RIFE smoke test. No video files or queue submission."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch


def load_package(name, folder):
    spec = importlib.util.spec_from_file_location(name, folder / '__init__.py',
                                                 submodule_search_locations=[str(folder)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run(comfy_root, original_dir):
    sys.path.insert(0, str(comfy_root.resolve()))
    import torch
    if not torch.cuda.is_available():
        raise RuntimeError('Run this smoke test in the actual ComfyUI CUDA environment')
    old_arguments = sys.argv
    try:
        sys.argv = [old_arguments[0]]
        original_package = load_package('nora_smoke_original_rife', original_dir.resolve())
        addon = load_package('nora_smoke_cut_addon', Path(__file__).resolve().parent)
    finally:
        sys.argv = old_arguments
    original_class = original_package.NODE_CLASS_MAPPINGS['RIFEInterpolation']
    original = original_class()
    wrapper = original._get_or_load_model('flownet.pkl', use_fp16=True)
    original_schedule = wrapper._calculate_target_frame_positions(24, 30, 8)
    images = torch.zeros((8, 64, 64, 3), dtype=torch.float32)
    for index in range(8):
        images[index, 8:24, 8 + index:24 + index, :] = 0.2
    images[4:] += 0.6
    baseline = original.interpolate(images, 24.0, 30.0, 1.0,
                                    model_name='flownet.pkl', batch_size=1, use_fp16=True)[0]
    addon_nodes = sys.modules['nora_smoke_cut_addon.nodes']
    node = addon.NODE_CLASS_MAPPINGS['NoraRIFEInterpolationCutTest']()
    with patch.object(addon_nodes, 'upstream_class', return_value=original_class):
        protected = node.interpolate(images, 24.0, 30.0, 1.0, scene_cut_threshold=0.15,
                                     model_name='flownet.pkl', batch_size=1, use_fp16=True)
        disabled = node.interpolate(images, 24.0, 30.0, 1.0, scene_cut_threshold=0.0,
                                    model_name='flownet.pkl', batch_size=1, use_fp16=True)
    output, fps, report_text = protected['result']
    report = json.loads(report_text)
    assert tuple(output.shape) == (10, 64, 64, 3), output.shape
    assert fps == 30.0
    assert torch.isfinite(output).all()
    assert report['cut_source_indices'] == [4], report
    assert report['protected_output_indices'] == [4], report
    assert torch.equal(output[4], images[3]), 'Cross-cut output is not an exact source-frame hold'
    unaffected = [n for n in range(10) if n != 4]
    assert torch.allclose(output[unaffected], baseline[unaffected], atol=0.001, rtol=0.001)
    assert torch.allclose(disabled['result'][0], baseline, atol=0.001, rtol=0.001)
    assert '_calculate_target_frame_positions' not in wrapper.__dict__, 'Original cached wrapper was patched'
    assert wrapper._calculate_target_frame_positions(24, 30, 8) == original_schedule
    assert set(addon.NODE_CLASS_MAPPINGS) == {'NoraRIFEInterpolationCutTest'}
    return {'ok': True, 'real_torch_real_weights': True, 'output_frames': len(output),
            'fps': fps, 'cut_report': report, 'original_wrapper_unchanged': True,
            'normal_frames_match_original': True, 'disabled_matches_original': True,
            'no_video_exported': True}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--comfy-root', type=Path, required=True)
    parser.add_argument('--original-node-dir', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.comfy_root, args.original_node_dir), ensure_ascii=False, indent=2))
