import importlib.util
import json
import math
from pathlib import Path
import sys
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('nora_cut_test', ROOT / '__init__.py',
                                              submodule_search_locations=[str(ROOT)])
package = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = package
spec.loader.exec_module(package)
core = sys.modules['nora_cut_test.cut_protection']
nodes = sys.modules['nora_cut_test.nodes']


class OriginalWrapper:
    def __init__(self):
        self.model = object()

    def _calculate_target_frame_positions(self, source_fps, target_fps, count):
        # Mirrors the installed upstream's global schedule, not a per-shot grid.
        output = []
        for n in range(int(count / source_fps * target_fps)):
            position = n / target_fps * source_fps
            left = int(position)
            right = min(left + 1, count - 1)
            output.append((left, right, position - left if left != right else 0.0))
        return output


class CutProtectionTests(unittest.TestCase):
    def test_automatic_hard_cut_detection(self):
        x = np.zeros((8, 4, 4, 3), np.float32)
        x[4:] = 1
        cuts, scores = core.detect_cuts(x)
        self.assertEqual(cuts, [4])
        self.assertEqual(scores[3], 1)

    def test_gradual_motion_like_changes_do_not_trigger_low_differences(self):
        x = np.arange(20, dtype=np.float32)[:, None, None, None] / 100
        x = np.broadcast_to(x, (20, 4, 4, 3))
        self.assertEqual(core.detect_cuts(x)[0], [])

    def test_color_changes_are_not_lost_by_grayscale_conversion(self):
        x = np.zeros((2, 4, 4, 3), np.float32)
        x[0, ..., 0] = 1
        x[1, ..., 1] = 1
        self.assertEqual(core.detect_cuts(x)[0], [1])

    def test_threshold_zero_disables_protection(self):
        x = np.ones((2, 2, 2, 3), np.float32)
        x[0] = 0
        self.assertEqual(core.detect_cuts(x, 0), ([], []))

    def test_single_frame(self):
        self.assertEqual(core.detect_cuts(np.zeros((1, 2, 2, 3)))[0], [])

    def test_invalid_thresholds(self):
        for threshold in (-0.1, 1.1, math.nan, math.inf):
            with self.subTest(threshold=threshold), self.assertRaises(ValueError):
                core.detect_cuts(np.zeros((2, 2, 2, 3)), threshold)

    def test_only_cross_cut_interpolation_is_replaced(self):
        positions = [(0, 1, 0.5), (1, 2, 0.5), (2, 3, 0.0), (3, 3, 0.0)]
        output, held = core.protect_positions(positions, [2])
        self.assertEqual(output, [(0, 1, 0.5), (1, 1, 0.0), (2, 3, 0.0), (3, 3, 0.0)])
        self.assertEqual(held, [1])

    def test_multiple_cuts_do_not_shorten_the_global_timeline(self):
        wrapper = OriginalWrapper()
        original = wrapper._calculate_target_frame_positions(24, 30, 345)
        # Includes boundaries that do not align with the output frame grid.
        cuts = [1, 3, 9, 152, 201, 344]
        output, _ = core.protect_positions(original, cuts)
        self.assertEqual(len(output), 431)
        self.assertEqual(len(output), len(original))
        self.assertTrue(all(not (right in cuts and left != right and t != 0)
                            for left, right, t in output))
        self.assertLess(345 / 24 - len(output) / 30, 1 / 30)

    def test_p003_cut_matches_previous_test_without_manual_split(self):
        base = OriginalWrapper()
        wrapper, stats = core.protected_wrapper(base, [152])
        output = wrapper._calculate_target_frame_positions(24, 30, 345)
        self.assertEqual(len(output), 431)
        self.assertEqual(stats['protected_output_indices'], [189])
        self.assertEqual(output[189], (151, 151, 0.0))
        self.assertEqual(output[190][0], 152)

    def test_no_cut_is_identical_to_upstream_schedule(self):
        base = OriginalWrapper()
        wrapper, _ = core.protected_wrapper(base, [])
        self.assertEqual(wrapper._calculate_target_frame_positions(24, 30, 345),
                         base._calculate_target_frame_positions(24, 30, 345))

    def test_wrapper_copy_does_not_patch_cached_model_or_original_node(self):
        base = OriginalWrapper()
        original = base._calculate_target_frame_positions(24, 30, 345)
        protected, _ = core.protected_wrapper(base, [152])
        unprotected, _ = core.protected_wrapper(base, [])
        protected._calculate_target_frame_positions(24, 30, 345)
        self.assertIs(protected.model, base.model)
        self.assertNotIn('_calculate_target_frame_positions', base.__dict__)
        self.assertEqual(base._calculate_target_frame_positions(24, 30, 345), original)
        self.assertEqual(unprotected._calculate_target_frame_positions(24, 30, 345), original)

    def test_selected_fps_are_not_hardcoded_to_thirty(self):
        base = OriginalWrapper()
        for source, target, count in ((24, 60, 345), (24, 24, 345), (30, 24, 301),
                                       (24000 / 1001, 30, 345)):
            with self.subTest(source=source, target=target):
                wrapper, _ = core.protected_wrapper(base, [152])
                out = wrapper._calculate_target_frame_positions(source, target, count)
                self.assertEqual(len(out), len(base._calculate_target_frame_positions(source, target, count)))

    def test_only_separate_test_node_is_registered(self):
        self.assertEqual(set(package.NODE_CLASS_MAPPINGS), {'NoraRIFEInterpolationCutTest'})
        self.assertNotIn('RIFEInterpolation', package.NODE_CLASS_MAPPINGS)
        cls = package.NODE_CLASS_MAPPINGS['NoraRIFEInterpolationCutTest']
        self.assertEqual(cls.RETURN_TYPES, ('IMAGE', 'FLOAT', 'STRING'))
        self.assertEqual(cls.INPUT_TYPES()['required']['target_fps'][1]['default'], 30.0)


if __name__ == '__main__':
    unittest.main()
