"""Separate opt-in node using the installed ComfyUI-VFI RIFE implementation."""
from contextlib import nullcontext
import json
import math

from .cut_protection import detect_cuts, protected_wrapper


def upstream_class():
    import nodes as comfy_nodes
    original = comfy_nodes.NODE_CLASS_MAPPINGS.get('RIFEInterpolation')
    if original is None:
        raise RuntimeError('Original RIFEInterpolation is not loaded; install/review ComfyUI-VFI first')
    return original


class NoraRIFEInterpolationCutTest:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            'required': {
                'images': ('IMAGE',),
                'source_fps': ('FLOAT', {'default': 24.0, 'min': 1.0, 'max': 120.0}),
                'target_fps': ('FLOAT', {'default': 30.0, 'min': 1.0, 'max': 240.0}),
                'scale': ('FLOAT', {'default': 1.0, 'min': 0.25, 'max': 4.0}),
                'scene_cut_threshold': ('FLOAT', {'default': 0.15, 'min': 0.0, 'max': 1.0,
                                                'step': 0.01, 'tooltip': 'RGB difference on 64x64 samples; 0 disables protection'}),
            },
            'optional': {
                'model_name': (['flownet.pkl'], {'default': 'flownet.pkl'}),
                'batch_size': ('INT', {'default': 1, 'min': 1, 'max': 32}),
                'use_fp16': ('BOOLEAN', {'default': True}),
            },
        }

    RETURN_TYPES = ('IMAGE', 'FLOAT', 'STRING')
    RETURN_NAMES = ('images', 'fps', 'cut_report')
    FUNCTION = 'interpolate'
    CATEGORY = 'Nora/Test/Video'
    DESCRIPTION = 'Opt-in RIFE automatic cut protection; preserves original global timing and the original RIFEInterpolation node.'

    def interpolate(self, images, source_fps, target_fps, scale, scene_cut_threshold=0.15,
                    model_name='flownet.pkl', batch_size=1, use_fp16=True):
        import torch
        import torch.nn.functional as functional

        if images.ndim != 4 or images.shape[-1] != 3 or len(images) == 0:
            raise ValueError('Expected nonempty IMAGE batch [N, H, W, 3]')
        if not all(math.isfinite(v) and v > 0 for v in (source_fps, target_fps, scale)):
            raise ValueError('Frame rates and scale must be positive and finite')
        if not math.isfinite(scene_cut_threshold) or not 0 <= scene_cut_threshold <= 1:
            raise ValueError('scene_cut_threshold must be between 0 and 1')
        report = {'node': 'NoraRIFEInterpolationCutTest', 'version': 'test-1',
                  'detector': '64x64 RGB mean absolute difference',
                  'scene_cut_threshold': scene_cut_threshold, 'source_fps': source_fps,
                  'target_fps': target_fps, 'source_frame_count': len(images),
                  'cut_source_indices': [], 'cut_times_seconds': [],
                  'protected_output_indices': []}
        if source_fps == target_fps:
            result = images
            report.update(passthrough=True, output_frame_count=len(images))
        else:
            # Downsample in bounded batches without copying the full input tensor.
            cuts, scores = [], []
            if scene_cut_threshold > 0:
                samples = []
                for batch in images.split(32):
                    small = functional.interpolate(batch.detach().movedim(-1, 1).float(),
                                                   size=(64, 64), mode='area')
                    samples.append(small.movedim(1, -1).cpu().numpy())
                import numpy as np
                cuts, scores = detect_cuts(np.concatenate(samples), scene_cut_threshold)
            report.update(cut_source_indices=cuts,
                          cut_times_seconds=[n / source_fps for n in cuts],
                          cut_scores=[scores[n - 1] for n in cuts])
            original = upstream_class()()
            # Reuse the installed node's weights, cache and model implementation.
            base = original._get_or_load_model(model_name, use_fp16=use_fp16)
            model, stats = protected_wrapper(base, cuts)
            autocast = torch.amp.autocast('cuda') if use_fp16 and torch.cuda.is_available() else nullcontext()
            with autocast:
                result = model.interpolate_frames(images=images, source_fps=source_fps,
                                                  target_fps=target_fps, scale=scale,
                                                  batch_size=batch_size)
            report.update(stats)
            if len(result) != report['output_frame_count']:
                raise RuntimeError('Installed RIFE wrapper returned a different output frame count')
        report.update(output_duration_seconds=len(result) / target_fps,
                      duration_quantization_seconds=len(result) / target_fps - len(images) / source_fps)
        text = json.dumps(report, ensure_ascii=False)
        print('NORA_RIFE_CUT_REPORT ' + text)
        return {'ui': {'text': [text]}, 'result': (result, float(target_fps), text)}


NODE_CLASS_MAPPINGS = {'NoraRIFEInterpolationCutTest': NoraRIFEInterpolationCutTest}
NODE_DISPLAY_NAME_MAPPINGS = {'NoraRIFEInterpolationCutTest': 'Nora RIFE Auto Cut Protection (TEST)'}
