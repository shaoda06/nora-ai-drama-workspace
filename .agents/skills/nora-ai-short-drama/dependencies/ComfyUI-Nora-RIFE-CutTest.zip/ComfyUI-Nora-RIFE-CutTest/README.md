# Nora RIFE自动切镜保护节点

节点接口类名为`NoraRIFEInterpolationCutTest`，安装目录为`ComfyUI-Nora-RIFE-CutTest`。类名和目录名是固定兼容接口，正式工作流直接使用；不覆盖原`RIFEInterpolation`。默认30fps，阈值0.15；阈值0关闭保护。节点按64×64 RGB相邻帧差异检测切镜，在原RIFE整段时间表的跨切点位置保持源帧，其余位置使用原模型；不处理音轨。

## 依赖与安装

复用现有GACLove/ComfyUI-VFI的`RIFEInterpolation`、PyTorch/CUDA、NumPy和已有`flownet.pkl`。不自动下载或升级。像素差检测对闪光、快速运动或相似构图可能误判，成果仍按视频流程交用户审核。

在已有安装目录外解压，使用实际ComfyUI Python执行：

```text
<ComfyUI Python> -X utf8 -B preflight.py --comfy-root <ComfyUI根目录> --original-node-dir <ComfyUI-VFI目录>
<ComfyUI Python> -X utf8 -B -m unittest discover -s tests -v
<ComfyUI Python> -X utf8 -B smoke_test.py --comfy-root <ComfyUI根目录> --original-node-dir <ComfyUI-VFI目录>
```

preflight只读检查接口和已有权重；unittest不使用GPU；smoke_test使用真实CUDA及现有权重，检查切镜保持、30fps计数、普通帧与关闭保护时的原版一致性、原缓存不被修改，不导出项目视频。无兼容环境或检查失败时停止，不替换原节点或模型。13项单元测试和GPU smoke_test均退出0才可继续安装。

安装和重启须有对应授权，GPU测试及重启仅在无活动或排队任务时进行。通过后复制本文件夹到实际`custom_nodes/ComfyUI-Nora-RIFE-CutTest`；已有不同内容不覆盖。使用既有管理方式受控重启，确认原`RIFEInterpolation`与`NoraRIFEInterpolationCutTest`同时注册，后者输出IMAGE、FLOAT、STRING。保留实际路径和测试证据，不将节点注册视为视频获批。

## 回退

服务空闲并停止后，仅将本节点文件夹移到custom_nodes之外，再用原方式启动。原ComfyUI-VFI、模型和旧工作流保留；不要在custom_nodes内仅改后缀。切换AusBoss备用工作流仍需该任务明确选择，不自动重处理已有视频。

## 许可证

本包保留MIT许可证，只提供独立适配代码和测试，不包含第三方模型权重或原ComfyUI-VFI代码。
