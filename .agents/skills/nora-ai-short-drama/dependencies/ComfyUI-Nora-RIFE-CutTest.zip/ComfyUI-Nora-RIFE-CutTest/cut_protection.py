"""Source cut detection and protection on the existing, global RIFE timeline."""
import copy
import math
from types import MethodType

import numpy as np


def detect_cuts(rgb_samples, threshold=0.15):
    """Return zero-based first-frame indices of cuts and adjacent RGB MAD scores.

    Samples are small RGB images normalized to [0, 1]. A zero threshold disables
    detection. This is a pixel-difference detector, not a semantic scene model.
    """
    if not math.isfinite(threshold) or not 0 <= threshold <= 1:
        raise ValueError('scene_cut_threshold must be finite and between 0 and 1')
    samples = np.asarray(rgb_samples, dtype=np.float32)
    if samples.ndim != 4 or samples.shape[-1] != 3 or len(samples) == 0:
        raise ValueError('Expected nonempty [frames, height, width, 3] samples')
    if threshold == 0 or len(samples) == 1:
        return [], []
    scores = np.abs(samples[1:] - samples[:-1]).mean(axis=(1, 2, 3))
    cuts = (np.flatnonzero(scores > threshold) + 1).tolist()
    return cuts, scores.tolist()


def protect_positions(positions, cut_indices):
    """Keep the output grid unchanged; replace only cross-cut jobs by a hold."""
    cuts = set(cut_indices)
    protected = []
    held_outputs = []
    for output_index, (left, right, fraction) in enumerate(positions):
        if fraction != 0 and left != right and right in cuts:
            protected.append((left, left, 0.0))
            held_outputs.append(output_index)
        else:
            protected.append((left, right, fraction))
    return protected, held_outputs


def protected_wrapper(base_wrapper, cut_indices):
    """Use the original weights/inference on a per-call wrapper copy.

    No cached wrapper, class or original node is patched. Upstream's own
    _calculate_target_frame_positions remains the source of timing and counts.
    The upstream wrapper already copies source frames for (left, left, 0).
    """
    calculate = base_wrapper._calculate_target_frame_positions
    wrapper = copy.copy(base_wrapper)
    stats = {}

    def positions(self, source_fps, target_fps, total_source_frames):
        original = calculate(source_fps, target_fps, total_source_frames)
        result, held = protect_positions(original, cut_indices)
        stats.update(output_frame_count=len(result), protected_output_indices=held)
        return result

    wrapper._calculate_target_frame_positions = MethodType(positions, wrapper)
    return wrapper, stats
