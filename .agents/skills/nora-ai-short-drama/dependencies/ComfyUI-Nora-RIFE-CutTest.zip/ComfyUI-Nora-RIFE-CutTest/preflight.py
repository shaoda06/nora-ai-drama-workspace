"""Read-only compatibility check; does not import ComfyUI or load weights."""
import argparse
import ast
import hashlib
import json
from pathlib import Path


def check(comfy_root, original_dir):
    required = {
        'nodes.py': {'RIFEInterpolation': {
            '_get_or_load_model': {'model_name', 'use_fp16'},
        }},
        'rife/rife_comfyui_wrapper.py': {'RIFEWrapper': {
            '_calculate_target_frame_positions': {'source_fps', 'target_fps', 'total_source_frames'},
            'interpolate_frames': {'images', 'source_fps', 'target_fps', 'scale', 'batch_size'},
        }},
    }
    evidence = []
    for name, expected in required.items():
        path = original_dir / name
        raw = path.read_bytes()
        source = raw.decode('utf-8-sig')
        tree = ast.parse(source, filename=str(path))
        for class_name, methods in expected.items():
            cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == class_name)
            for method, parameters in methods.items():
                function = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == method)
                actual = {n.arg for n in function.args.args + function.args.kwonlyargs}
                if not parameters <= actual:
                    raise ValueError(f'Incompatible upstream method: {class_name}.{method}')
        if name.endswith('rife_comfyui_wrapper.py'):
            if 'self._calculate_target_frame_positions(' not in source or 'source_idx1 == source_idx2' not in source:
                raise ValueError('Review upstream scheduling/direct-copy logic before installing')
        evidence.append({'file': str(path.resolve()), 'sha256': hashlib.sha256(raw).hexdigest()})
    locations = (original_dir / 'rife/train_log/flownet.pkl', original_dir / 'models/flownet.pkl',
                 comfy_root / 'models/rife/flownet.pkl')
    weights = next((p for p in locations if p.is_file()), None)
    if weights is None:
        raise FileNotFoundError('Existing flownet.pkl not found; do not auto-download a replacement')
    return {'compatible_surface': True, 'original_sources': evidence,
            'existing_weights': str(weights.resolve()), 'weights_bytes': weights.stat().st_size,
            'runtime_inference_tested': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--comfy-root', type=Path, required=True)
    parser.add_argument('--original-node-dir', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(check(args.comfy_root, args.original_node_dir), ensure_ascii=False, indent=2))
